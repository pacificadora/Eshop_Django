from django.contrib import admin

# Register your models here.
# inorder to show the field of products that we created admin need to register the Product class

from .models.product import Product  #.product is file name and Product is class in the file
from .models.category import Category #.category is the file name and Category is the class in the file
from .models.customer import Customer
from .models.orders import Order

# this class is made to display the table on the admin site
class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']

# this class is made to display the table on the admin site
class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Customer)
admin.site.register(Order)