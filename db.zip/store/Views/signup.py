"""
views.py is the logic soul and every thing of the project.
"""

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
# make password is converting the input password into the hashed password while signing up
# check password is checks the hashed password that the password is matching for a user while login
from django.http import HttpResponse
# Create your views here.
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View


class SignUp(View):
    """Initially these 3 functions were here and there but after creating class made the functions come all together
     and now when the signup is called we know which functions are in use."""

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        return self.registeruser(request)

    def registeruser(self, request):
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # creating an object for the Customer class in customer.py
        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)
        # validation
        error_message = self.validatecustomer(customer)

        # print(first_name, last_name, phone, email, password)

        """values dictionary is created so that when an error occured and after that the page is reloaded the values 
        already there must remain there"""
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }

        if not error_message:
            customer.password = make_password(customer.password)
            customer.registration()
            return redirect('homepage')
            # when the form is completed after filling the form, the page will be redirected to the homepage i.e the index.html
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

            """
            work flow is
            1 - First of all the user will go on to signup url
            2 - There the views of store application is accessed 
            3 - If the request is GET then the simple signup page will be rendered
            4 - if the request is POST, i.e the form is being filled and user has clicked on 'Create an Account'. The form will provide user's information
            5 - After providing the information, the credentials will be stored in above variables
            6 - then the obejct (customer) is created for the Customer class to call the class method registration
            7 - With the help of function/method registration defined in the model customer.py the data is getting directly stored in DB
            #return HttpResponse(request.POST.get('email'))
            """

    def validatecustomer(self, customer):
        # validation
        error_message = None
        if not customer.first_name:
            error_message = 'First name required'
        elif len(customer.first_name) < 4:
            error_message = 'First name must be greater than 4 or equal to 4'
        elif not customer.last_name:
            error_message = 'Last name required'
        elif len(customer.last_name) < 4:
            error_message = 'Last name must be greater than 4 or equal to 4'
        elif not customer.phone:
            error_message = 'Phone Number required'
        elif len(customer.phone) < 10:
            error_message = 'Enter valid phone number'
        elif not customer.password:
            error_message = 'Password required'
        elif len(customer.phone) < 6:
            error_message = 'Enter valid Password(greater than 6)'
        elif customer.isExist():  # object is calling the function of the class Customer
            error_message = 'Email address already registered'

        return error_message
        # print(first_name, last_name, phone, email, password)


"""
def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        return registeruser(request)
"""
