"""
views.py is the logic soul and every thing of the project.
"""

from django.shortcuts import render, redirect
# Create your views here.
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View
#this is used to convert the functions into class format


class Index(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        # prod = Product.get_all_product()
        prod = None
        cate = Category.get_all_categories()
        # this is the class named Product calling its function named get_all_product() that is defined in the models.product
        # this is the class named Category calling its function named get_all_categories() that is defined in the models.category

        categoryid = request.GET.get('category')
        if categoryid:
            prod = Product.get_all_products_by_Categoryid(categoryid)
        else:
            prod = Product.get_all_product()
        data = {}
        data['products'] = prod
        data['categories'] = cate
        print('you are : ', request.session.get('email'))
        return render(request, 'index.html', data)

    def post(self, request):
        product_id = request.POST.get('product')#this will give the product id
        remove = request.POST.get('remove')
        #yaha se jo product milega isse main ek dictionary me save karunga. Key will be product_id and value will be its quantity
        print(product_id)
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product_id)
            if quantity:
                if remove:
                    if quantity==1:
                        cart.pop(product_id)
                    else:
                        cart[product_id] = quantity-1
                else:
                    cart[product_id] = quantity+1
            else:
                cart[product_id] = 1
        else:
            cart = {}
            cart[product_id] = 1

        request.session['cart'] = cart
        print('cart : ', request.session['cart'])
        return redirect('homepage')





"""
def index(request):
    #prod = Product.get_all_product()
    prod = None
    cate = Category.get_all_categories()
    # this is the class named Product calling its function named get_all_product() that is defined in the models.product
    # this is the class named Category calling its function named get_all_categories() that is defined in the models.category

    categoryid = request.GET.get('category')
    if categoryid:
        prod = Product.get_all_products_by_Categoryid(categoryid)
    else:
        prod = Product.get_all_product()
    data = {}
    data['products'] = prod
    data['categories'] = cate

    print('you are : ' + request.session.get('email'))
    return render(request, 'index.html', data)
"""