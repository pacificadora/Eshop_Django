"""
views.py is the logic soul and every thing of the project.
"""

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
#make password is converting the input password into the hashed password while signing up
#check password is checks the hashed password that the password is matching for a user while login
from django.http import HttpResponse
# Create your views here.
from store.models.product import Product
from django.views import View
from store.models.orders import Order
from store.models.customer import Customer
class Order_view(View):
    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Order.get_orders_by_customer(customer)
        #print(orders)
        return render(request, 'orders.html', {"orders": orders})



