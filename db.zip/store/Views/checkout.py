"""
views.py is the logic soul and every thing of the project.
"""

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
#make password is converting the input password into the hashed password while signing up
#check password is checks the hashed password that the password is matching for a user while login
from django.http import HttpResponse
# Create your views here.
from store.models.product import Product
from django.views import View
from store.models.orders import Order
from store.models.customer import Customer

class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        product_ids = list(cart.keys())
        products = Product.get_products_by_id(product_ids)
        print(address, phone, customer, cart, products)

        for product in products:
            order = Order(customer = Customer(id = customer),
                          product = product,
                          price = product.price,
                          address = address,
                          phone = phone,
                          quantity = cart.get(str(product.id)))
            order.placeorder()
        request.session['cart'] = {}#after placing the order the cart should be empty hence the cart is replaced by empty dictionary
        return redirect('cart')



