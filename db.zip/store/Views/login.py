"""
views.py is the logic soul and every thing of the project.
"""

from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import make_password, check_password
#make password is converting the input password into the hashed password while signing up
#check password is checks the hashed password that the password is matching for a user while login
from django.http import HttpResponse
# Create your views here.
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View

class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            if check_password(password, customer.password):
                """request.session['customer'] = customer 
                    This statement throws this error - TypeError at /login
                    Object of type 'Customer' is not JSON serializable
                    Hence below 2 statements are written
                """
                """Below 2 statements are reading the customer id and its email into a session so that the custmer
                is need to login once. 
                """
                request.session['customer_id'] = customer.id
                request.session['email'] = customer.email
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                error_message = 'Enter valid email or password'
        else:
            error_message = 'User Does Not exist, signup to explore more'

        print(customer)
        return render(request, 'login.html', {'error': error_message})
"""so basically the function login is now converted into class based approach
further changes to be made in store url. This makes the code object oriented and also more clean"""

""" 
def login(request):
    if request.method == 'GET' :
        return render(request, 'login.html')
    else:
"""


def logout(request):
    request.session.clear()
    return redirect('login')