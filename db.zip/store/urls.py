from django.contrib import admin
from django.urls import path
from .Views.home import Index
from .Views.signup import SignUp
from .Views.login import Login, logout
from .Views.cart import Cart
from .Views.checkout import Checkout
from .Views.order import Order_view
from .middlewares.auth import auth_middleware #we have imported the middleware that we want to apply

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup', SignUp.as_view(), name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name = 'cart'),
    path('checkout', Checkout.as_view(), name = 'checkout'),
    path('orders', auth_middleware(Order_view.as_view()), name ='orders')
    #we want to apply the middleware in the orders page hence we can directly do that from here
    # keeping the name of the pages helps in redirecting
]
