from django.db import models
from .category import Category
class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    description = models.CharField(max_length=200, default=" ")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1, null=True, blank=True)
    #foreign key is there to make connections between Product and Category table
    image = models.ImageField(upload_to='uploads/products/')

    @staticmethod
    def get_all_product():
        return Product.objects.all()

    #filtering the prducts according to the category id
    @staticmethod
    def get_all_products_by_Categoryid(category_id):
        if category_id:
            return Product.objects.filter(category = category_id)
        else:
            return Product.get_all_product()

    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in = ids)